<?php
    require_once("../../factory/conexao.php");
    if($_POST('cxcarro') != ""){
        $conn = new caminho();
        $query = "insert into tbcarros
        (carro, fabricante, valor, ano)
        values
        (:nome, :fabri, :valor, :ano)";
        $cadastrar = $conn->getConn()->
        prepare($query);

        $cadastrar->bindParam
        (':nome',$_POST['cxnome'],PDO::PARAM_STR);

        $cadastrar->bindParam
        (':fabri',$_POST['cxfabricante'],PDO::PARAM_STR);

        $cadastrar->bindParam
        (':valor',$_POST['cxvalor'],PDO::PARAM_INT);

        $cadastrar->bindParam
        (':ano',$_POST['cxano'],PDO::PARAM_INT);

        $cadastrar->execute();
        if(cadastrar->rowCount()){
            echo "Dados cadastrados com sucesso!    ";
        }
        else{
            echo "Dados não cadastrados!";
        }
    }
    else{

    }
?>