<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tabela de Amigos</title>
    <link rel="stylesheet" type="text/css" href="../css/estiloamigo.css">
</head>
<body>
<div id="titulo"><h2>Lista de Amigos</h2></div>
<section class="container-table">
  <table>
    <thead>
      <tr>
        <th>Nome</th>
        <th>E-mail</th>
        <th>Data de Nascimento</th>
        <th>Telefone</th>
        <th colspan="2">Ação</th>
      </tr>
    </thead>
    <?php
    require "../factory/conexao.php";
    $sql = "select * from tbamigos order by nome ASC";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
      while ($row = $result->fetch_assoc()) {
    ?>

    <tbody>
    <tr>
      <td><?= $row['nome'] ?></td>
      <td><?= $row['email'] ?></td>
      <td><?= $row['datanasc'] ?></td>
      <td><?= $row['tel'] ?></td>
     
      <td>
      <form action="../model/alteraramigo.php" method="GET"> 
        <input type="hidden" name="id" value="<?= $row['cond'] ?>">
        <input id="butalterar"type="submit" class="botao-editar" value="Editar">
        </form>
      </td>
      <td>
        <form action="excluir-produto.php" method="GET">
          <input type="hidden" name="id" value="<?= $row['cond'] ?>">
          <input id="butdeletar" type="submit" class="botao-excluir" value="Excluir">
        </form>
      </td>
      
    </tr>
    <?php }
              }
              ?>
    </tbody>
  </table>
<a class="botao-cadastrar" href="cadastrar-produto.php">Cadastrar produto</a>
</section>
</body>
</html>