<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastrar Amigo</title>
    <link rel="stylesheet" type="text/css" href="../css/estiloamigo.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
</head>
<body>
    <div id="titulo"><h2>Cadastrar Novo Amigo</h2></div>
    <form action="../model/inseriramigo.php" method="POST" class="inserirdados">
        <h4>Nome:</h4><input type="text" name="cxamigo" class="cxamigo">
        <h4>E-mail:</h4><input type="text" name="cxemail" class="cxemail">
        <h4>Data de nascimento:</h4><input type="date" name="cxdatanasc" class="cxdatanasc">
        <h4>Telefone:</h4><input type="text" name="cxtelefone" class="cxtelefone">
        <input type="submit" value="Cadastrar">
    </form><br>
    <form action="../model/consultaamigonome.php" method="POST" >
            <label for="">Digite o nome completo de usuário</label><br>
            <input type="text" name="cxpesquisa"/>
            <input type="submit" value="Pesquisa"/>
        </form>

    <div id="titulo">
        <h2>Lista de Amigos</h2>
</div>
    <section class="tabela">
    <table>
      <thead>
        <tr>
          <th>Nome</th>
          <th>E-mail</th>
          <th>Data de Nascimento</th>
          <th>Telefone</th>
          <th colspan="2">Ação</th>
        </tr>
      </thead>
      <?php
      require "../factory/conexao.php";
      $sql = "select * from tbamigos order by nome ASC";
      $result = $conn->query($sql);

      if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
      ?>

      <tbody>
      <tr>
        <td><?= $row['nome'] ?></td>
        <td><?= $row['email'] ?></td>
        <td><?= $row['datanasc'] ?></td>
        <td><?= $row['tel'] ?></td>
       
        <td>
        <form action="../model/consultaamigonome.php" method="GET"> 
          <input type="hidden" name="id" value="<?= $row['cod'] ?>">
          <input type="submit" class="botao-alterar" value="Alterar">
          </form>
        </td>
        <td>
          <form onsubmit="excluirProduto();" method="POST" id="excluirForm">
            <input type="hidden" name="id" value="<?= $row['cod'] ?>">
            <input type="submit" class="botao-excluir" value="Excluir">
          </form>
        </td>
        
      </tr>
      <?php }
                }
                ?>
      </tbody>
    </table>
  </section>
</body>
</html>