<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="inserircomercio.php" method="POST">
        <h4>Contato:</h4><input type="text" name="cxcontato" class="cxcontato">
        <h4>Empresa:</h4><input type="text" name="cxempresa" class="cxempresa">
        <h4>Telefone:</h4><input type="tel" name="cxtelefone" class="cxtelefone">
        <h4>E-mail:</h4><input type="text" name="cxemail" class="cxemail">
        <input type="submit" value="Cadastrar">
    </form>
</body>
</html>