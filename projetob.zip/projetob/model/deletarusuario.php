<?php 
    include_once "conexao.php";
    $id = $_POST["cxcodigo"];
    $nome = $_POST["cxnome"];
    $email = $_POST["cxemail"];
    $senha = $_POST["cxsenha"];
    
    $alterar = "DELETE FROM tbusuario
        nome = '$nome', 
        email = '$email',
        senha = '$senha' 
        where codigo = '$id' 
    ";
    $executar = mysqli_query($conn, $alterar);
    if($executar){
            echo "Dados alterados com sucesso!";
    } else {
            echo "Erro ao alterar os dados!";
    }
?>
<a href="consultausernome.php">Voltar</a>