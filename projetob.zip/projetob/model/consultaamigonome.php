<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alterar Amigo</title>
    <link rel="stylesheet" type="text/css" href="../css/estiloamigo.css">
</head>
<body>
<?php
        include_once "../factory/conexao.php";
        $nome = $_POST["cxamigo"];
        $consulta = "select * from tbamigos where nome = '$nome'";
        $executar = mysqli_query($conn,$consulta);
        $linha = mysqli_fetch_array($executar);
   ?>
   <form action="alteraramigo.php" method="POST">
   Código: <br>
    <input type="text" name="cxcodigo" 
    value="<?php echo $linha["cond"] ?>"disabled/><br>
   Nome:
   <input type="text" name="cxnome" value="<?php echo $linha['nome']?>"/><br>
   E-mail:
   <input type="text" name="cxemail" value="<?php echo $linha['email']?>"/><br> 
   Data de Nascimento:
   <input type="date" name="cxnasc" value="<?php echo $linha['datanasc']?>"/><br>
   Telefone:
   <input type="text" name="cxtelefone" value="<?php echo $linha['tel']?>"/> <br>
   <input type="submit" value="Alterar">
   </form>
</body>
</html>