<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alterar Comércio</title>
    <link rel="stylesheet" type="text/css" href="../css/estiloalterarandexcluir.css">
</head>
<body>
<?php 
        include_once "../factory/conexao.php";
        $pesquisa = $_POST["cxcomercio"];
        $consulta = "select * from tbcomercio where empresa = '$pesquisa' ";
        $executar = mysqli_query($conn, $consulta);
        $linha = mysqli_fetch_array($executar);
    ?>
    <form action="alterarcomercio.php" method="POST">
    Código: <br>
    <input type="text" name="cxcodigo" 
    value="<?php echo $linha["cod"] ?>" disabled/><br>
    Contato: <br>
    <input type="text" name="cxcontato" value="<?php echo $linha["contato"] ?>"/><br>
    Empresa: <br>
    <input type="text" name="cxempresa" value="<?php echo $linha["empresa"] ?>"/><br>
    Telefone: <br>
    <input type="text" name="cxtelefone" value="<?php echo $linha["tel"] ?>"/><br>
    Email: <br>
    <input type="text" name="cxemail" value="<?php echo $linha["email"] ?>"/><br><br>
    <input type="submit" value="Alterar">
    </form>
</body>
</html>