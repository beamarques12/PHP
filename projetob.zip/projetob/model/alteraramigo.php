<?php 
    include_once "../factory/conexao.php";
    $id = $_POST["cxcodigo"];
    $nome = $_POST["cxnome"];
    $email = $_POST["cxemail"];
    $datanasc = $_POST["cxnasc"];
    $telefone = $_POST["cxtelefone"];
    
    $alterar = "UPDATE tbcomercio SET
        nome = '$nome', 
        email = '$email',
        datanasc = '$datanasc',
        telefone = '$telefone'
        where codigo = '$id' 
    ";
    $executar = mysqli_query($conn, $alterar);
    if($executar){
            echo "Dados alterados com sucesso!";
    } else {
            echo "Erro ao alterar os dados!";
    }
?>
<a href="consultaamigonome.php">Voltar</a>