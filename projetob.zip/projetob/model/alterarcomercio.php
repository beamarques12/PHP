<?php 
    include_once "../factory/conexao.php";
    $id = $_POST["cxcodigo"];
    $contato = $_POST["cxcontato"];
    $empresa = $_POST["cxempresa"];
    $telefone = $_POST["cxtelefone"];
    $email = $_POST["cxemail"];
    
    $alterar = "UPDATE tbcomercio SET
        contato = '$contato', 
        empresa = '$empresa',
        telefone = '$telefone',
        email = '$email'
        where codigo = '$id' 
    ";
    $executar = mysqli_query($conn, $alterar);
    if($executar){
            echo "Dados alterados com sucesso!";
    } else {
            echo "Erro ao alterar os dados!";
    }
?>
<a href="consultacomercionome.php">Voltar</a>