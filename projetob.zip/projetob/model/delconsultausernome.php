<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alterar Usuário</title>
    <link rel="stylesheet" href="../css/estiloalterarandexcluir.css">
</head>
<body>
   <?php
        include_once "../factory/conexao.php";
        $nome = $_POST["cxusuario"];
        $consulta = "select * from tbusuario where nome = '$nome'";
        $executar = mysqli_query($conn,$consulta);
        $linha = mysqli_fetch_array($executar);
   ?>
   <form action="deletarusuario.php?cod=<?php echo $linha['cod'] ?>" method="POST">
   Código: <br>
    <input type="text" name="cxcodigo" 
    value="<?php echo $linha["cod"] ?>" disabled/><br>
   Nome:
   <input type="text" name="cxnome" value="<?php echo $linha['nome']?>"/><br>
   E-mail:
   <input type="text" name="cxemail" value="<?php echo $linha['email']?>"/><br> 
   Senha:
   <input type="text" name="cxsenha" value="<?php echo $linha['senha']?>"/><br>
   <input type="submit" value="Deletar">
   </form>
</body>
</html>