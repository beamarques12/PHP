<?php

use app\models\Usuarios;

include  'Usuarios.php';

class Teste {
	public function __construct() {
		$usuario1 = new Usuarios();
		$usuario1 ->load("0", "baaaka@123.com", "1234", "1", "Twink", "34492384312", "rua a", "jd aaa", "guaruja", "sp", "07329433", "11934832473", "a", "sim") 
		
		if  ($usuario1->checkLogin()){
			
		}else{
			
		}
	
	}	
}

$teste = new Teste();
