<?php
        include_once "../control/cadastroGeral.php";
        $cadastro = new CadastroGeral;
        $cadastro->Professor('Anselmo', 'Rua: 12-123', '11934850345', 'Professor', '45 anos', 'anselmo@gmail.com', '293.456.376.87');
        $cadastro->Aluno('Beatriz', 'Rua: 12-123', '11934850345', 'Estudante', '17 anos', 'beamarques006@gmail.com', '293.456.376.87');
?>