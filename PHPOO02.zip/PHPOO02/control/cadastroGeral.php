<?php
    class CadastroGeral{
        public $nome;
        public $endereco;
        public $fone;
        public $tipo;
        public $idade;
        public $email;
        public $cpf;

        function Professor ($no, $en, $fo, $ti, $id, $em, $cpf){
            echo "<h1>Dados do professor</h1>";
            echo "Nome: ".$this->nome = $no."<br/>";
            echo "Endereço: ".$this->endereco = $en."<br/>";
            echo "Telefone: ".$this->fone = $fo."<br/>";
            echo "Tipo: ".$this->tipo = $ti."<br/>";
            echo "Idade: ".$this->idade = $id."<br/>";
            echo "Email: ".$this->email = $em."<br/>";
            echo "CPF: ".$this->cpf = $cpf."<br/>";
        }
        function Aluno ($no, $en, $fo, $ti, $id, $em, $cpf){
            echo "<h1>Dados do aluno</h1>";
            echo "Nome: ".$this->nome = $no."<br/>";
            echo "Endereço: ".$this->endereco = $en."<br/>";
            echo "Telefone: ".$this->fone = $fo."<br/>";
            echo "Tipo: ".$this->tipo = $ti."<br/>";
            echo "Idade: ".$this->idade = $id."<br/>";
            echo "Email: ".$this->email = $em."<br/>";
            echo "CPF: ".$this->cpf = $cpf."<br/>";
        }
    }