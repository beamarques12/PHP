<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <?php include_once "../control/cadastroGeral.php"; ?>
</head>
<body>
<?php
        $cadastro = new CadastroGeral;
        $cadastro->Professor('Anselmo', 'Rua: 12-123', '11934850345', 'Professor', '45 anos', 'anselmo@gmail.com', '293.456.376.87');
        $cadastro->Aluno('Beatriz', 'Rua: 12-123', '11934850345', 'Estudante', '17 anos', 'beamarques006@gmail.com', '293.456.376.87');
        ?>
</body>
<h1>Cadastro </h1>
    <form action="" method="POST">
        Nome: <br>
        <input type="text" name="cxnome"><br>
        Endereço: <br>
        <input type="text" name="cxend"><br>
        Idade: <br>
        <input type="text" name="cxidade"><br>
        Telefone: <br>
        <input type="text" name="cxtelefone"><br>
        E-mail: <br>
        <input type="text" name="cxemail"><br>
        CPF: <br>
        <input type="number" name="cxcpf"><br>
        Tipo: <br>
        <input type="text" name="cxtipo"><br>
        <input type="submit" value="Enviar">
    </form>
</html>