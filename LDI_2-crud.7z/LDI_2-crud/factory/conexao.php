<?php
    $server="localhost";
    $user="root";
    $password = "";
    $dbname = "bdagendatb";
    $conn = mysqli_connect($server, $user, $password, $dbname);
?>