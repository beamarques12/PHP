<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu principal</title>
    <link rel="stylesheet" type ="text/css" href="css/estilo.css">
</head>
<body>
    <header id="banner">
        <a href="cadastrarcliente.php">
            Cadastrar Cliente
        </a>
    </header>
    <section id="corpo"></section>
</body>
</html>