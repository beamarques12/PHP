<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Gestão</title>
</head>
<body>
    HOME | História | Contatos - Perfil:
        <hr>
        <h1>Cadastrar Amigo</h1>
        <a href="amigo/telacadamigo.php">
        Cadastrar
        </a> 
        | Consultar | Alterar | Excluir
</body>
</html>