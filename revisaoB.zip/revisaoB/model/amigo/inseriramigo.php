<?php
    if($_POST["cxnome"] != "")
    {
        include_once "../../factory/conexao.php";
        $nome = $_POST["cxnome"];
        $apelido = $_POST["cxapelido"];
        $email = $_POST["cxemail"];
        $inserir = "insert into tbamigos (amigo,apelido,email)
        values 
        ('$nome', '$apelido', '$email')";
        $executar = mysqli_query($caminho,$inserir);
        echo "
            <script>
                alert('Cadastrado com sucesso!');
                window.location.href='../../view/index.php';
            </script>";
    }
    else
    {
        echo "Dados não cadastrados";
    }

?>