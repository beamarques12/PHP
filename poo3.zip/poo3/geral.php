<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <?php include_once "control/gato.php";
    include_once "control/cachorro.php"; ?>
</head>

<body>
<?php 
        $dados = new Gato;
        $dados->exibirGato();
        
        $dados = new Cachorro;
        $dados->exibirCachorro();
    ?>
</body>
</html>