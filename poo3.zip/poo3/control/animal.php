<?php
    class Animal{
        public $nome;
        public $raca;
        public $pelo;
        public $cor;
    }
?>