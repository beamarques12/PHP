<?php 
include_once "animal.php";

    class Cachorro extends Animal{
        public $tutor = "Beatriz";
        public $endereco = "XXXXXXXXXXXXXX, 234 - XXXXXXXXX";
            function exibirCachorro(){
                echo "<h1>Meu Cachorro</h1>";
                echo "Nome: " .$this->nome="Nuemo" ."<br/>";
                echo "Raça: " .$this->raca="Vira lata" ."<br/>";
                echo "Pelo: " .$this->pelo="Baixo" . "<br/>";
                echo "Cor: " .$this->cor="Ruivo" . "<br/>";
                echo "Tutor: " .$this->tutor . "<br/>";
                echo "Endereço: " .$this->endereco . "<br/>";
        }
    }
?>