<?php 
include_once "animal.php";
    class Gato extends Animal{
        public $tutor = "Beatriz";
            public $endereco = "XXXXXXXXXXXXXX, 234 - XXXXXXXXX";
        function exibirGato(){
            echo "<h1>Meu Gato</h1>";
            echo "Nome: " .$this->nome="Gustavo" ."<br/>";
            echo "Raça: " .$this->raca="Vira lata" ."<br/>";
            echo "Pelo: " .$this->pelo="Baixo" . "<br/>";
            echo "Cor: " .$this->cor="Preto" . "<br/>";
            echo "Tutor: " .$this->tutor . "<br/>";
            echo "Endereço: " .$this->endereco . "<br/>";
        }
    }
?>