<?php 
    class Pai{
        public $nome = "Anselmo";
        public $idade = 45;
    }
?>