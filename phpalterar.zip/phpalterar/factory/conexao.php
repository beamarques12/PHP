<?php
    $server = "localhost";
    $user ="root";
    $senha ="";
    $dbname = "bdmarvel";
    $conn = mysqli_connect($server,$user,$senha,$dbname);
?>