<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consulta</title>
</head>
<body>
    <form action="telaexibirdadosprodutos.php" method="POST">
        Digite o nome do produto: <br>
        <input type="text" name="cxproduto"/>
        <input type="submit" value="Pesquisar">
    </form>
</body>
</html>