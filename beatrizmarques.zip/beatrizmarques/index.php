<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap 5 Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>

<div class="container-fluid p-5 bg-danger p-3 text-white text-center">
  <h1>Beatriz Marques</h1>
  <p>Conheça um pouco sobre mim</p>
</div>
<nav class="navbar navbar-expand-sm bg-danger navbar-dark">
  <div class="container-fluid">
    <ul class="navbar-nav" role="tablist">
      <li class="nav-item">
        <a class="nav-link active" data-bs-toggle="pill" href="#home">Sobre Mim</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" data-bs-toggle="pill" href="#trabalhos">Meus Trabalhos</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" data-bs-toggle="pill" href="#contato">Contato</a>
      </li>
    </ul>
  </div>
</nav>

<div class="tab-content">
    
    <div id="home" class="container tab-pane active"><br>
      <h3>HOME</h3>
      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
    </div>
    
    <div id="trabalhos" class="container tab-pane fade"><br>
      <h3>Meus Trabalhos</h3> <br>
      
          <!-- Carrossel -->
            <div id="demo" class="carousel slide" data-bs-ride="carousel">
    
          <!-- Indicators/dots -->
          <div class="carousel-indicators">
            <button type="button" data-bs-target="#demo" data-bs-slide-to="0" class="active"></button>
            <button type="button" data-bs-target="#demo" data-bs-slide-to="1"></button>
            <button type="button" data-bs-target="#demo" data-bs-slide-to="2"></button>
          </div>
          
          <!-- The slideshow/carousel -->
          <div class="carousel-inner">
            <div class="carousel-item active">
              <img src="la.jpg" alt="Los Angeles" class="d-block" style="width:100%">
            </div>
            <div class="carousel-item">
              <img src="chicago.jpg" alt="Chicago" class="d-block" style="width:100%">
            </div>
            <div class="carousel-item">
              <img src="ny.jpg" alt="New York" class="d-block" style="width:100%">
            </div>
          </div>
          
          <!-- Left and right controls/icons -->
          <button class="carousel-control-prev" type="button" data-bs-target="#demo" data-bs-slide="prev">
            <span class="carousel-control-prev-icon"></span>
          </button>
          <button class="carousel-control-next" type="button" data-bs-target="#demo" data-bs-slide="next">
            <span class="carousel-control-next-icon"></span>
          </button>
        	</div>
        	<p>Lorem ipsum<p>
    </div>
    
    <div id="contato" class="container tab-pane fade"><br>
      <h3>Contato</h3>
      <div class="container mt-3">
      	<h2>Entre em contato</h2>
  
      <form action="/action_page.php">
        <div class="mb-3 mt-3">
          <label for="email">Email:</label>
          <input type="email" class="form-control" id="email" placeholder="Enter email" name="email">
        </div>
        <div class="mb-3">
          <label for="pwd">Senha:</label>
          <input type="password" class="form-control" id="pwd" placeholder="Enter password" name="pswd">
        </div>
        <div class="form-check mb-3">
          <label class="form-check-label">
            <input class="form-check-input" type="checkbox" name="remember"> Lembre-me
          </label>
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
      </form>
      
</div>
    </div>
  </div>
</div>
</body>
</html>