<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IMC</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Kanit:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
</head>
<body>
    <header>
        <a href="#"><img src="logo/imc.png" alt=""></a>
</header>
    <?php
    $nome = $_GET['nome'];
    $altura = $_GET['altura'];
    $peso = $_GET ['peso'];
    $imc = $peso / ($altura * $altura);
    ?>
        <div id="tabela">
        <div class="dados">
            <?php
        echo("Nome: " . $nome . "<br>");
        echo("Altura: " . $altura . "<br>");
        echo("Resultado do IMC: " . $imc . "<br>");
        ?>
        </div>
        <div class="resultado">
        <?php
        if($imc < 18.5){
            echo("Baixo peso");
        } else if($imc >= 18.5 && $imc < 24.99 ){
            echo("Normal");
        } else if($imc >= 24.99 && $imc < 29.99){
            echo("Sobrepeso");
        } else if($imc > 30){
            echo("Obesidade");
        }
        ?>
        </div>
        </div>
</body>
</html>