<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IMC</title>
</head>
<body>
    <?php
    $nome = $_GET['nome'];
    $altura = $_GET['altura'];
    $peso = $_GET ['peso'];
    $imc = $peso / ($altura * $altura);
        echo("Nome: " . $nome . "<br>");
        echo("Altura: " . $altura . "<br>");
        echo("Resultado do IMC: " . $imc . "<br>");
        if($imc < 18.5){
            echo("Baixo peso");
        } else if($imc >= 18.5 && $imc < 24.99 ){
            echo("Normal");
        } else if($imc >= 24.99 && $imc < 29.99){
            echo("Sobrepeso");
        } else if($imc > 30){
            echo("Obesidade");
        }
    ?>
</body>
</html>